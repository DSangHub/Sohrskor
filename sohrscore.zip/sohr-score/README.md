# SOHR Score

A Next.js 14 (App Router) web app that gives homeowners a free "SOHR Score" for their home's major components (roof, HVAC, windows, floors, and more), with sign-up, a personal dashboard, and score history. Backed by PostgreSQL via Prisma and NextAuth for authentication.

---

## Why this repo was restructured

The original `DSangHub/Sohrskor` repo stored every code snippet as a **separate extensionless file named after its code-block language** (`Jsx`, `JavaScript`, `Json1`, `bash`, `Table`…), all in the root folder. There was no `package.json`, no `app/` directory, and no file extensions — so Vercel (and Railway) had no framework entry point and nothing to route, which is exactly what produced the **404 on every URL**.

This version reorganizes those same snippets into a proper Next.js project:

| Original file | New location |
| --- | --- |
| `Jsx` | `app/page.js` (homepage) |
| `Jsx1` | `app/how-it-works/page.js` |
| `Jsx2` | `app/login/page.js` |
| `Jsx3` | `app/signup/page.js` |
| `JavaScript` | `lib/calculator.js` |
| `JavaScript1` | `app/api/calculate/route.js` |
| `JavaScript2` | `app/api/save-score/route.js` |
| `JavaScript3` | `app/api/auth/[...nextauth]/route.js` |
| `javascript4` | `app/api/health/route.js` |
| `prisma` | `prisma/schema.prisma` |
| `Json` / `Json1` / `json4` | merged into `package.json` + `vercel.json` |

New files were added to make it actually run: `app/layout.js`, `app/globals.css`, `app/dashboard/page.js`, `app/api/auth/signup/route.js`, `lib/db.js`, and the config files (`next.config.js`, `jsconfig.json`, `tailwind.config.js`, `postcss.config.js`).

Three bugs in the original code were also fixed:
- **`calculateBCI`** returned the wrong value first (`totalWeight / totalWeighted`), so every score was wrong. Now returns the correct weighted average.
- **Prisma `User`** had no `password` field, but the auth and signup code read/write `user.password`. Added it.
- **`estimateValueImpact`** is now available where the calculator needs it.

---

## How the app flows (now wired end-to-end)

1. **Homepage** — visitor types their address and clicks *Get My Free Score*, which routes to `/score?address=…`.
2. **Score page (`/score`)** — sliders for each component's age. Clicking *Calculate My Score* POSTs to `/api/calculate` and renders the live report: overall SOHR Score, grade, condition/upkeep breakdown, per-component scores, recommended next steps, and estimated value impact.
3. **Save** — logged-in users get a *Save to My Dashboard* button that POSTs to `/api/save-score`; visitors are prompted to create a free account first. Saved scores show up on `/dashboard` with history.

The address input, sliders, calculate, and save are all functional client components (`components/AddressForm.js`, `components/ScoreTool.js`), wrapped in a NextAuth `SessionProvider` (`components/Providers.js`) so the save flow knows who's logged in.

## Project structure

```
sohr-score/
├── app/
│   ├── layout.js                 # Shared nav/footer, global styles
│   ├── page.js                   # Homepage
│   ├── globals.css
│   ├── how-it-works/page.js
│   ├── login/page.js
│   ├── signup/page.js
│   ├── score/page.js            # Interactive score calculator
│   ├── dashboard/page.js         # Protected — requires login
│   └── api/
│       ├── calculate/route.js        # POST — computes SOHR Score
│       ├── save-score/route.js       # POST — saves score to DB
│       ├── health/route.js           # GET  — DB health check
│       └── auth/
│           ├── [...nextauth]/route.js # NextAuth handler
│           └── signup/route.js        # POST — creates account
├── components/
│   ├── AddressForm.js           # Hero address input (client)
│   ├── ScoreTool.js             # Sliders + live report (client)
│   └── Providers.js             # NextAuth SessionProvider (client)
├── lib/
│   ├── calculator.js             # Core SOHR formula
│   └── db.js                     # Prisma client singleton
├── prisma/
│   └── schema.prisma
├── package.json
├── vercel.json                   # Vercel config
├── railway.json                  # Railway config
├── Dockerfile                    # Optional container build
├── .env.example
└── README.md
```

---

## 1. Run it locally first

```bash
npm install
cp .env.example .env
# edit .env — set DATABASE_URL, NEXTAUTH_SECRET, NEXTAUTH_URL
npx prisma db push      # creates the tables in your database
npm run dev
```

Open http://localhost:3000.

Generate a secret with:

```bash
openssl rand -base64 32
```

You need a PostgreSQL database even for local dev. The easiest free options are [Neon](https://neon.tech) or [Supabase](https://supabase.com) — create a database and paste its connection string into `DATABASE_URL`.

---

## 2. Push to GitHub

Your existing repo history is full of the old loose files. The cleanest fix is to replace the contents:

```bash
# from inside this sohr-score/ folder
git init
git add .
git commit -m "Restructure into a deployable Next.js project"
git branch -M main
git remote add origin https://github.com/DSangHub/Sohrskor.git
git push -u origin main --force
```

> `--force` overwrites the old loose-file contents. If you'd rather keep the old files in history, create a **new** repo instead and push there without `--force`.

---

## 3a. Deploy to Vercel

Vercel hosts the app but **not** the database, so you provide Postgres separately.

1. Go to [vercel.com/new](https://vercel.com/new) and import `DSangHub/Sohrskor`.
2. Vercel auto-detects Next.js — leave the build settings as-is (`vercel.json` already sets `prisma generate && next build`).
3. Add a database: in the project, go to **Storage → Create Database → Postgres** (Neon-backed), or bring your own Neon/Supabase URL.
4. Under **Settings → Environment Variables**, add:
   - `DATABASE_URL` — your Postgres connection string
   - `NEXTAUTH_SECRET` — output of `openssl rand -base64 32`
   - `NEXTAUTH_URL` — `https://<your-project>.vercel.app`
5. Click **Deploy**.
6. After the first deploy, push your schema to the database once:
   ```bash
   # locally, with DATABASE_URL pointing at the production DB
   npx prisma db push
   ```

If you still get a 404 after this, it means the old commit is still deployed — trigger a redeploy from the latest `main`.

---

## 3b. Deploy to Railway

Railway can host **both** the app and the Postgres database in one project, which fits this Prisma setup nicely.

1. Go to [railway.app](https://railway.app) → **New Project → Deploy from GitHub repo** → select `Sohrskor`.
2. Railway auto-detects Next.js via Nixpacks (`railway.json` sets the start command).
3. In the same project, click **New → Database → PostgreSQL**. Railway provisions it and exposes a `DATABASE_URL`.
4. Open your **app service → Variables** and add:
   - `DATABASE_URL` — reference the Postgres plugin's value (`${{Postgres.DATABASE_URL}}`)
   - `NEXTAUTH_SECRET` — a long random string
   - `NEXTAUTH_URL` — your Railway public URL (e.g. `https://sohrskor.up.railway.app`)
5. Deploy. Then open the service's **Shell** tab and run once:
   ```bash
   npx prisma db push
   ```
6. Click the generated domain to open the app.

> You can deploy to **both** platforms from the same repo — they read their own config files (`vercel.json` vs `railway.json`) and don't conflict. Just make sure each has its own env vars and its own database, and set `NEXTAUTH_URL` to match that platform's domain.

---

## Health check

Once deployed, visit `/api/health` — it returns `{ "status": "healthy", "database": "connected" }` when the app can reach Postgres. Great for confirming your `DATABASE_URL` is wired correctly.

---

## Environment variables reference

| Variable | Required | Description |
| --- | --- | --- |
| `DATABASE_URL` | ✅ | PostgreSQL connection string |
| `NEXTAUTH_SECRET` | ✅ | Signs auth session tokens (`openssl rand -base64 32`) |
| `NEXTAUTH_URL` | ✅ | Full public URL of the deployment, no trailing slash |
