"use client";
import { useState } from "react";
import { useSearchParams } from "next/navigation";
import { useSession } from "next-auth/react";
import Link from "next/link";

// Must mirror the weights/lifespans in lib/calculator.js so the on-screen
// per-component breakdown matches the server's overall score.
const COMPONENTS = [
  { key: "roof", label: "Roof", lifespan: 25 },
  { key: "hvac", label: "HVAC", lifespan: 15 },
  { key: "woodFlours", label: "Wood Floors", lifespan: 30 },
  { key: "windows", label: "Windows", lifespan: 20 },
  { key: "carpet", label: "Carpet", lifespan: 10 },
  { key: "blinds", label: "Blinds", lifespan: 12 },
  { key: "waterHeater", label: "Water Heater", lifespan: 7 },
];

function componentScore(age, lifespan) {
  return Math.max(0, Math.round((1 - age / lifespan) * 100));
}

function barColor(score) {
  if (score >= 70) return "bg-green-500";
  if (score >= 50) return "bg-yellow-500";
  if (score >= 30) return "bg-orange-500";
  return "bg-red-500";
}

function gradeStyles(grade) {
  switch (grade) {
    case "Excellent":
      return { text: "text-green-600", ring: "ring-green-200", bg: "bg-green-50" };
    case "Good":
      return { text: "text-blue-600", ring: "ring-blue-200", bg: "bg-blue-50" };
    case "Fair":
      return { text: "text-yellow-600", ring: "ring-yellow-200", bg: "bg-yellow-50" };
    default:
      return { text: "text-red-600", ring: "ring-red-200", bg: "bg-red-50" };
  }
}

export default function ScoreTool() {
  const searchParams = useSearchParams();
  const address = searchParams.get("address") || "";
  const { data: session } = useSession();

  const [ages, setAges] = useState(
    Object.fromEntries(COMPONENTS.map((c) => [c.key, Math.round(c.lifespan / 2)]))
  );
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [saveMsg, setSaveMsg] = useState("");
  const [saving, setSaving] = useState(false);

  const setAge = (key, value) =>
    setAges((prev) => ({ ...prev, [key]: Number(value) }));

  const buildComponents = () => {
    const components = Object.fromEntries(
      COMPONENTS.map((c) => [c.key, { age: ages[c.key] }])
    );
    components.address = address;
    return components;
  };

  const calculate = async () => {
    setLoading(true);
    setError("");
    setSaveMsg("");
    try {
      const res = await fetch("/api/calculate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ components: buildComponents(), replacements: [] }),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || "Could not calculate your score.");
      }
      setResult(await res.json());
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  const saveReport = async () => {
    if (!result) return;
    setSaving(true);
    setSaveMsg("");
    try {
      const res = await fetch("/api/save-score", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: session.user.id,
          components: buildComponents(),
          replacements: [],
          scoreResult: result,
        }),
      });
      setSaveMsg(res.ok ? "Saved to your dashboard ✓" : "Could not save — try again.");
    } catch {
      setSaveMsg("Could not save — try again.");
    } finally {
      setSaving(false);
    }
  };

  const valueImpactText =
    result &&
    (typeof result.valueImpact === "number"
      ? `${result.valueImpact >= 0 ? "+" : "-"}$${Math.abs(
          result.valueImpact
        ).toLocaleString()}`
      : result.valueImpact?.formatted);

  const styles = result ? gradeStyles(result.grade) : null;

  return (
    <main className="max-w-3xl mx-auto py-12 px-4">
      <h1 className="text-4xl font-extrabold tracking-tight text-slate-900">
        Your SOHR Score
      </h1>
      {address ? (
        <p className="text-slate-500 mt-1 mb-8">for {address}</p>
      ) : (
        <p className="text-slate-500 mt-1 mb-8">
          Adjust the ages below to estimate your home&apos;s score.
        </p>
      )}

      {/* Sliders */}
      <section className="rounded-2xl border border-slate-200 bg-white p-6 sm:p-8 shadow-sm">
        <h2 className="text-lg font-semibold text-slate-900">
          How old is each component?
        </h2>
        <p className="text-sm text-slate-500 mb-6">
          Drag each slider to the component&apos;s age in years. Not sure? Our
          midpoint estimate is a fine starting point.
        </p>
        <div className="space-y-6">
          {COMPONENTS.map((c) => (
            <div key={c.key}>
              <div className="flex justify-between text-sm mb-2">
                <span className="font-medium text-slate-800">{c.label}</span>
                <span className="text-slate-500">
                  <span className="font-semibold text-slate-900">{ages[c.key]}</span> yrs
                  <span className="text-slate-300"> / </span>
                  ~{c.lifespan} yr life
                </span>
              </div>
              <input
                type="range"
                min="0"
                max={c.lifespan}
                value={ages[c.key]}
                onChange={(e) => setAge(c.key, e.target.value)}
                className="w-full"
              />
            </div>
          ))}
        </div>
        <button
          onClick={calculate}
          disabled={loading}
          className="mt-8 w-full inline-flex items-center justify-center gap-2 py-3.5 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700 disabled:opacity-60 shadow-sm shadow-blue-600/25"
        >
          {loading && (
            <svg className="h-5 w-5 animate-spin" viewBox="0 0 24 24" fill="none">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
            </svg>
          )}
          {loading ? "Calculating…" : "Calculate My Score"}
        </button>
        {error && <p className="text-red-500 text-center mt-3">{error}</p>}
      </section>

      {/* Results */}
      {result && (
        <section className="mt-8 animate-fade-up">
          <div
            className={`rounded-2xl p-8 text-center ring-1 ${styles.ring} ${styles.bg}`}
          >
            <p className="text-sm uppercase tracking-wide font-semibold text-slate-500">
              SOHR Score
            </p>
            <p className="text-7xl font-extrabold text-slate-900 my-1 animate-pop-in">
              {result.score}
            </p>
            <p className={`text-xl font-bold ${styles.text}`}>{result.grade}</p>
            <div className="mt-4 flex justify-center gap-6 text-sm text-slate-500">
              <span>
                Condition <span className="font-semibold text-slate-800">{result.bci}</span>
              </span>
              <span>
                Upkeep <span className="font-semibold text-slate-800">{result.pri}</span>
              </span>
            </div>
            {valueImpactText && (
              <p className="mt-4 text-slate-700">
                Estimated value impact:{" "}
                <span className="font-semibold">{valueImpactText}</span>
              </p>
            )}
          </div>

          {/* Component breakdown */}
          <div className="mt-8">
            <h2 className="text-2xl font-semibold text-slate-900 mb-4">
              Component Breakdown
            </h2>
            <div className="space-y-3">
              {COMPONENTS.map((c) => {
                const s = componentScore(ages[c.key], c.lifespan);
                return (
                  <div key={c.key}>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="font-medium text-slate-800">
                        {c.label}{" "}
                        <span className="text-slate-400">({ages[c.key]} yrs)</span>
                      </span>
                      <span className="font-semibold text-slate-900">{s}</span>
                    </div>
                    <div className="h-2.5 w-full rounded-full bg-slate-100 overflow-hidden">
                      <div
                        className={`h-full rounded-full ${barColor(s)} transition-all`}
                        style={{ width: `${s}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Recommendations */}
          {result.recommendations?.length > 0 && (
            <div className="mt-8">
              <h2 className="text-2xl font-semibold text-slate-900 mb-4">
                Recommended Next Steps
              </h2>
              <ul className="space-y-3">
                {result.recommendations.map((r) => (
                  <li
                    key={r.component}
                    className="rounded-xl border border-amber-200 bg-amber-50 px-4 py-3"
                  >
                    <div className="flex items-center gap-2">
                      <span className="font-semibold capitalize text-slate-900">
                        {r.component}
                      </span>
                      <span
                        className={`text-xs font-semibold rounded-full px-2 py-0.5 ${
                          r.urgency === "High"
                            ? "bg-red-100 text-red-700"
                            : "bg-amber-100 text-amber-700"
                        }`}
                      >
                        {r.urgency} priority
                      </span>
                    </div>
                    <p className="text-sm text-slate-600 mt-1">{r.action}</p>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Save CTA */}
          <div className="mt-8 rounded-2xl bg-slate-900 text-white p-7 text-center">
            {session ? (
              <>
                <button
                  onClick={saveReport}
                  disabled={saving}
                  className="px-6 py-3 bg-white text-slate-900 rounded-xl font-semibold hover:bg-slate-100 disabled:opacity-60"
                >
                  {saving ? "Saving…" : "Save to My Dashboard"}
                </button>
                {saveMsg && <p className="mt-3 text-sm text-slate-200">{saveMsg}</p>}
              </>
            ) : (
              <>
                <p className="mb-4 text-slate-200">
                  Want to save this report and track it over time?
                </p>
                <Link
                  href="/signup"
                  className="inline-block px-6 py-3 bg-white text-slate-900 rounded-xl font-semibold hover:bg-slate-100"
                >
                  Create a Free Account
                </Link>
              </>
            )}
          </div>
        </section>
      )}
    </main>
  );
}
