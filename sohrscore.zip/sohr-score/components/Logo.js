export default function Logo({ className = "h-8 w-8" }) {
  return (
    <svg
      className={className}
      viewBox="0 0 32 32"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      {/* House */}
      <path
        d="M16 3 3 13v16a1 1 0 0 0 1 1h8v-9h8v9h8a1 1 0 0 0 1-1V13L16 3Z"
        fill="url(#sohrGrad)"
      />
      {/* Score check mark */}
      <path
        d="M11.5 17.5l3 3 6-6"
        stroke="#fff"
        strokeWidth="2.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <defs>
        <linearGradient id="sohrGrad" x1="3" y1="3" x2="29" y2="30" gradientUnits="userSpaceOnUse">
          <stop stopColor="#2563eb" />
          <stop offset="1" stopColor="#4f46e5" />
        </linearGradient>
      </defs>
    </svg>
  );
}

export function Wordmark({ className = "" }) {
  return (
    <span className={`inline-flex items-center gap-2 font-bold ${className}`}>
      <Logo className="h-7 w-7" />
      <span className="text-xl tracking-tight">
        <span className="text-blue-600">SOHR</span>
        <span className="text-gray-900">Score</span>
      </span>
    </span>
  );
}
