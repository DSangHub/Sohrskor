"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function AddressForm() {
  const [address, setAddress] = useState("");
  const router = useRouter();

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!address.trim()) return;
    router.push(`/score?address=${encodeURIComponent(address.trim())}`);
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="max-w-2xl mx-auto flex flex-col sm:flex-row gap-3"
    >
      <input
        type="text"
        value={address}
        onChange={(e) => setAddress(e.target.value)}
        placeholder="Enter your address (e.g., 123 Main St, Austin, TX)"
        className="flex-1 px-6 py-4 border border-gray-300 rounded-xl text-lg shadow-sm focus:ring-2 focus:ring-blue-500 outline-none"
      />
      <button
        type="submit"
        className="px-8 py-4 bg-blue-600 text-white text-lg font-semibold rounded-xl hover:bg-blue-700 transition shadow-lg"
      >
        Get My Free Score →
      </button>
    </form>
  );
}
