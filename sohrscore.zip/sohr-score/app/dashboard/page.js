import { getServerSession } from 'next-auth';
import { redirect } from 'next/navigation';
import Link from 'next/link';
import { authOptions } from '../api/auth/[...nextauth]/route';
import { prisma } from '@/lib/db';

function gradeText(grade) {
  switch (grade) {
    case 'Excellent':
      return 'text-green-600';
    case 'Good':
      return 'text-blue-600';
    case 'Fair':
      return 'text-yellow-600';
    default:
      return 'text-red-600';
  }
}

export default async function Dashboard() {
  const session = await getServerSession(authOptions);

  if (!session) {
    redirect('/login');
  }

  const scores = await prisma.score.findMany({
    where: { userId: session.user.id },
    orderBy: { createdAt: 'desc' },
    take: 10,
  });

  const latest = scores[0];

  return (
    <main className="max-w-4xl mx-auto py-16 px-4">
      <div className="flex items-end justify-between flex-wrap gap-4 mb-10">
        <div>
          <h1 className="text-4xl font-extrabold tracking-tight text-slate-900">
            Your Dashboard
          </h1>
          <p className="text-slate-500 mt-1">{session.user.email}</p>
        </div>
        <Link
          href="/score"
          className="rounded-xl bg-blue-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm shadow-blue-600/25 hover:bg-blue-700"
        >
          New Score
        </Link>
      </div>

      {latest ? (
        <div className="rounded-2xl bg-blue-50 ring-1 ring-blue-100 p-8 text-center mb-8">
          <p className="text-sm uppercase tracking-wide font-semibold text-slate-500">
            Your latest SOHR Score
          </p>
          <p className="text-7xl font-extrabold text-slate-900 my-1">{latest.score}</p>
          <p className={`text-xl font-bold ${gradeText(latest.grade)}`}>{latest.grade}</p>
          <div className="mt-4 flex justify-center gap-6 text-sm text-slate-500">
            <span>
              Condition <span className="font-semibold text-slate-800">{latest.bci}</span>
            </span>
            <span>
              Upkeep <span className="font-semibold text-slate-800">{latest.pri}</span>
            </span>
          </div>
        </div>
      ) : (
        <div className="rounded-2xl bg-slate-50 border border-slate-200 p-10 text-center mb-8">
          <p className="text-slate-600">You don&apos;t have a score yet.</p>
          <Link
            href="/score"
            className="mt-4 inline-block rounded-xl bg-blue-600 px-6 py-3 font-semibold text-white hover:bg-blue-700"
          >
            Calculate My Score
          </Link>
        </div>
      )}

      {scores.length > 1 && (
        <div>
          <h2 className="text-2xl font-semibold text-slate-900 mb-4">History</h2>
          <ul className="space-y-2">
            {scores.map((s) => (
              <li
                key={s.id}
                className="flex justify-between items-center bg-white border border-slate-200 rounded-xl px-4 py-3"
              >
                <span className="text-slate-500 text-sm">
                  {new Date(s.createdAt).toLocaleDateString()}
                </span>
                <span className="font-semibold text-slate-900">
                  {s.score}{' '}
                  <span className={`font-medium ${gradeText(s.grade)}`}>· {s.grade}</span>
                </span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </main>
  );
}
