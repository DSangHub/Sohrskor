import Link from 'next/link';

export const metadata = {
  title: 'How It Works — SOHR Score',
};

export default function HowItWorks() {
  const steps = [
    {
      num: '1',
      title: 'Enter your address',
      desc: 'It sets the context for your estimate and lets us tailor the value impact to your area.',
    },
    {
      num: '2',
      title: 'Tell us a few details',
      desc: 'Quick sliders for the age of your roof, HVAC, windows, and more — or keep our estimates and skip ahead.',
    },
    {
      num: '3',
      title: 'Get your score + report',
      desc: 'An instant SOHR Score, a component-by-component breakdown, personalized recommendations, and an estimated value impact.',
    },
  ];

  return (
    <main className="bg-white">
      <section className="bg-gradient-to-b from-blue-50 to-white">
        <div className="max-w-4xl mx-auto py-16 sm:py-20 px-4 text-center animate-fade-up">
          <h1 className="text-4xl sm:text-5xl font-extrabold tracking-tight text-slate-900">
            How it works — <span className="text-blue-600">3 simple steps</span>
          </h1>
          <p className="mt-4 text-lg text-slate-600 max-w-2xl mx-auto">
            No inspection, no paperwork. Just a few quick inputs and you&apos;ll know
            exactly where your home stands.
          </p>
        </div>
      </section>

      <section className="max-w-4xl mx-auto py-16 px-4">
        <div className="space-y-6">
          {steps.map((step) => (
            <div
              key={step.num}
              className="flex items-start gap-6 rounded-2xl border border-slate-200 bg-white p-6 sm:p-8 shadow-sm"
            >
              <div className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-full bg-blue-600 text-2xl font-bold text-white shadow-lg shadow-blue-600/30">
                {step.num}
              </div>
              <div>
                <h3 className="text-2xl font-semibold text-slate-900">{step.title}</h3>
                <p className="mt-1 text-lg text-slate-600">{step.desc}</p>
              </div>
            </div>
          ))}
        </div>

        {/* The formula, explained simply */}
        <div className="mt-14 rounded-2xl bg-slate-50 border border-slate-200 p-8">
          <h2 className="text-2xl font-bold text-slate-900">What goes into your score</h2>
          <p className="mt-3 text-slate-600">
            Your SOHR Score blends two ideas: how much useful life your components
            have left, and how well you keep them up to date.
          </p>
          <div className="mt-6 grid sm:grid-cols-2 gap-4">
            <div className="rounded-xl bg-white border border-slate-200 p-5">
              <p className="font-semibold text-blue-600">Base Condition Index</p>
              <p className="mt-1 text-sm text-slate-600">
                A weighted look at the remaining life of your roof, HVAC, windows,
                floors, and more. Worth 60% of your score.
              </p>
            </div>
            <div className="rounded-xl bg-white border border-slate-200 p-5">
              <p className="font-semibold text-indigo-600">Proactive Replacement Index</p>
              <p className="mt-1 text-sm text-slate-600">
                Credit for replacing components on time, before they fail. Worth
                40% of your score.
              </p>
            </div>
          </div>
        </div>

        <div className="mt-12 text-center">
          <Link
            href="/score"
            className="inline-block rounded-xl bg-blue-600 px-8 py-4 text-lg font-semibold text-white shadow-lg shadow-blue-600/25 hover:bg-blue-700"
          >
            Get My Free Score →
          </Link>
        </div>
      </section>
    </main>
  );
}
