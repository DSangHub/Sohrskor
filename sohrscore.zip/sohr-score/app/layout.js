import './globals.css';
import Link from 'next/link';
import Providers from '@/components/Providers';
import { Wordmark } from '@/components/Logo';

export const metadata = {
  title: 'SOHR Score — Know Your Home\'s Real Condition',
  description:
    "Get your home's free SOHR Score in 2 minutes. Rate your roof, HVAC, windows, and more. No purchase, no inspection, no spam.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="font-sans text-slate-900">
        <Providers>
          <header className="sticky top-0 z-40 w-full border-b border-slate-200/80 bg-white/80 backdrop-blur">
            <div className="max-w-6xl mx-auto flex items-center justify-between px-4 py-3.5">
              <Link href="/" aria-label="SOHR Score home">
                <Wordmark />
              </Link>
              <nav className="flex items-center gap-1 sm:gap-2 text-sm font-medium text-slate-600">
                <Link
                  href="/how-it-works"
                  className="hidden sm:inline-block px-3 py-2 rounded-lg hover:text-blue-600 hover:bg-slate-50"
                >
                  How It Works
                </Link>
                <Link
                  href="/login"
                  className="px-3 py-2 rounded-lg hover:text-blue-600 hover:bg-slate-50"
                >
                  Sign In
                </Link>
                <Link
                  href="/signup"
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 shadow-sm shadow-blue-600/20"
                >
                  Get My Score
                </Link>
              </nav>
            </div>
          </header>

          {children}

          <footer className="w-full border-t border-slate-200 bg-slate-50">
            <div className="max-w-6xl mx-auto px-4 py-10 flex flex-col sm:flex-row items-center justify-between gap-4">
              <Wordmark />
              <div className="flex items-center gap-6 text-sm text-slate-500">
                <Link href="/how-it-works" className="hover:text-blue-600">
                  How It Works
                </Link>
                <Link href="/login" className="hover:text-blue-600">
                  Sign In
                </Link>
                <Link href="/signup" className="hover:text-blue-600">
                  Get Started
                </Link>
              </div>
            </div>
            <div className="border-t border-slate-200 py-5 text-center text-xs text-slate-400">
              © {new Date().getFullYear()} SOHR Score · No purchase required · Your data stays private
            </div>
          </footer>
        </Providers>
      </body>
    </html>
  );
}
