import { Suspense } from 'react';
import ScoreTool from '@/components/ScoreTool';

export const metadata = {
  title: 'Your SOHR Score',
};

function Loading() {
  return (
    <main className="max-w-3xl mx-auto py-16 px-4">
      <div className="animate-pulse space-y-4">
        <div className="h-10 w-2/3 rounded-lg bg-slate-200" />
        <div className="h-64 rounded-2xl bg-slate-100" />
      </div>
    </main>
  );
}

export default function ScorePage() {
  return (
    <Suspense fallback={<Loading />}>
      <ScoreTool />
    </Suspense>
  );
}
