import Link from 'next/link';
import AddressForm from '@/components/AddressForm';

export default function Home() {
  return (
    <main className="min-h-screen bg-white">
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-b from-blue-50 via-white to-white">
        <div className="absolute inset-0 -z-10 opacity-60 [background:radial-gradient(60%_50%_at_50%_0%,#dbeafe_0%,transparent_70%)]" />
        <div className="max-w-4xl mx-auto text-center py-20 sm:py-28 px-4 animate-fade-up">
          <span className="inline-flex items-center gap-2 rounded-full border border-blue-200 bg-white/70 px-4 py-1.5 text-sm font-medium text-blue-700 shadow-sm">
            <span className="h-2 w-2 rounded-full bg-green-500" />
            Free · No signup to start · Results in 2 minutes
          </span>
          <h1 className="mt-6 text-4xl sm:text-6xl font-extrabold tracking-tight text-slate-900">
            What&apos;s your home&apos;s{' '}
            <span className="bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
              SOHR Score
            </span>
            ?
          </h1>
          <p className="mt-5 text-lg sm:text-xl text-slate-600 max-w-2xl mx-auto">
            A single 0–100 rating of your home&apos;s roof, HVAC, windows, floors,
            and more — with the two or three upgrades that raise it most.
          </p>

          <div className="mt-9">
            <AddressForm />
            <p className="text-sm text-slate-400 mt-4">
              No credit card. No inspection. No spam. Ever.
            </p>
          </div>
        </div>
      </section>

      {/* Social proof strip */}
      <section className="border-y border-slate-200 bg-slate-50">
        <div className="max-w-5xl mx-auto px-4 py-8 grid grid-cols-3 gap-6 text-center">
          {[
            { stat: '7', label: 'Components rated' },
            { stat: '2 min', label: 'To your score' },
            { stat: '$0', label: 'To get started' },
          ].map((s) => (
            <div key={s.label}>
              <p className="text-2xl sm:text-3xl font-extrabold text-slate-900">{s.stat}</p>
              <p className="text-sm text-slate-500 mt-1">{s.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Value boxes */}
      <section className="max-w-6xl mx-auto py-20 px-4">
        <h2 className="text-3xl font-bold text-center text-slate-900">
          Everything you need to protect your home&apos;s value
        </h2>
        <div className="mt-12 grid md:grid-cols-3 gap-6">
          {[
            {
              icon: '📊',
              title: 'Your score, instantly',
              desc: 'A clear 0–100 rating across roof, HVAC, windows, floors, and more — no jargon.',
            },
            {
              icon: '📈',
              title: 'Your neighborhood edge',
              desc: 'A higher score means more value at resale, even in a medium-demand market.',
            },
            {
              icon: '🛠️',
              title: 'Clear next steps',
              desc: 'We surface the two or three upgrades that move your score most — no pressure to buy.',
            },
          ].map((box) => (
            <div
              key={box.title}
              className="group rounded-2xl border border-slate-200 bg-white p-7 shadow-sm transition hover:shadow-md hover:border-blue-200"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-blue-50 text-2xl">
                {box.icon}
              </div>
              <h3 className="mt-5 text-xl font-semibold text-slate-900">{box.title}</h3>
              <p className="mt-2 text-slate-600">{box.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* How it works preview */}
      <section className="bg-slate-50 border-y border-slate-200">
        <div className="max-w-5xl mx-auto py-20 px-4">
          <h2 className="text-3xl font-bold text-center text-slate-900">
            Three simple steps
          </h2>
          <div className="mt-12 grid md:grid-cols-3 gap-8">
            {[
              { num: '1', title: 'Enter your address', desc: 'We use it to set the context for your estimate.' },
              { num: '2', title: 'Set a few ages', desc: 'Quick sliders for each component — or keep our estimates.' },
              { num: '3', title: 'Get your report', desc: 'Instant SOHR Score, recommendations, and value impact.' },
            ].map((step) => (
              <div key={step.num} className="text-center">
                <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-blue-600 text-2xl font-bold text-white shadow-lg shadow-blue-600/30">
                  {step.num}
                </div>
                <h3 className="mt-5 text-xl font-semibold text-slate-900">{step.title}</h3>
                <p className="mt-2 text-slate-600">{step.desc}</p>
              </div>
            ))}
          </div>
          <div className="mt-10 text-center">
            <Link href="/how-it-works" className="font-semibold text-blue-600 hover:underline">
              See how it works in detail →
            </Link>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="max-w-3xl mx-auto py-20 px-4">
        <h2 className="text-3xl font-bold text-center text-slate-900">Common questions</h2>
        <div className="mt-10 space-y-4">
          {[
            {
              q: 'Is it really free?',
              a: 'Yes. You can get your SOHR Score without paying or creating an account. An account is only needed if you want to save your report and track it over time.',
            },
            {
              q: 'Do I need an inspection?',
              a: 'No. Your score is estimated from the ages of your major components. The more accurate your inputs, the more accurate your score.',
            },
            {
              q: 'What does the score actually measure?',
              a: 'It blends a Base Condition Index (how much life your components have left) with a Proactive Replacement Index (how well you keep them up to date).',
            },
          ].map((item) => (
            <div key={item.q} className="rounded-2xl border border-slate-200 bg-white p-6">
              <h3 className="font-semibold text-slate-900">{item.q}</h3>
              <p className="mt-2 text-slate-600">{item.a}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Final CTA */}
      <section className="bg-gradient-to-r from-blue-600 to-indigo-600">
        <div className="max-w-4xl mx-auto text-center py-16 px-4">
          <h2 className="text-3xl sm:text-4xl font-bold text-white">
            Find your SOHR Score in two minutes
          </h2>
          <p className="mt-3 text-blue-100 text-lg">
            Free, private, and no obligation — ever.
          </p>
          <Link
            href="/score"
            className="mt-8 inline-block rounded-xl bg-white px-8 py-4 text-lg font-semibold text-blue-700 shadow-lg hover:bg-blue-50"
          >
            Get My Free Score →
          </Link>
        </div>
      </section>
    </main>
  );
}
